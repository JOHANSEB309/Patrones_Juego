/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package personajesjuego;

import Control.Controlador;
import java.io.IOException;

/**
 *
 * @author Johan Fontecha, Diana Ferraro, Andres Quintero
 */

public class PersonajesJuego {

    public static void main(String[] args) throws IOException {
        Controlador control = new Controlador();
        control.iniciar();
    }
    
}
